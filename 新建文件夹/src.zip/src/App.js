import React from 'react';
import "./App.css"
import State from "./components/state/state"
import Base from "./components/form/Base"
function App() {

  return (
    <div className="App">
      {/* state */}
      {/* <State></State> */}
      {/* 表单理论 */}
      <Base></Base>
    </div>
  );
}

export default App;
